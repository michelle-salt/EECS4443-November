# NovemberProposal
 
